package com.nick.buildcraft.content.block.refinery;

import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jetbrains.annotations.Nullable;

/**
 * A fluid tank that locks to a single fluid type once filled.
 * Supports an optional filter that restricts which fluid can enter.
 */
public class FilterableFluidTank extends FluidTank {

    /** The locked/filtered fluid type (amount = 1). Null means unrestricted. */
    @Nullable
    private FluidStack acceptedFluid = null;

    public FilterableFluidTank(int capacity) {
        super(capacity);
    }

    @Override
    public int fill(FluidStack resource, FluidAction action) {
        if (resource.isEmpty()) {
            return 0;
        }

        // Lock to first fluid we actually insert
        if (action.execute() && acceptedFluid == null) {
            acceptedFluid = resource.copyWithAmount(1);
        }

        if (!canAcceptFluid(resource)) {
            return 0;
        }

        return super.fill(resource, action);
    }

    public boolean canAcceptFluid(FluidStack resource) {
        if (resource.isEmpty()) return false;

        // If filter exists, enforce it
        if (acceptedFluid != null) {
            return FluidStack.isSameFluidSameComponents(acceptedFluid, resource);
        }

        // If tank already contains something, match the tank fluid
        if (!this.getFluid().isEmpty()) {
            return FluidStack.isSameFluidSameComponents(this.getFluid(), resource);
        }

        return true; // empty, no filter → anything allowed
    }

    public void setFilter(@Nullable FluidStack filter) {
        this.acceptedFluid = (filter == null || filter.isEmpty())
                ? null
                : filter.copyWithAmount(1);
    }

    @Nullable
    public FluidStack getFilter() {
        return acceptedFluid;
    }

    public boolean hasFilter() {
        return acceptedFluid != null;
    }

    /** Clears both fluid and filter. */
    public void reset() {
        this.setFluid(FluidStack.EMPTY);
        this.acceptedFluid = null;
    }

    public void clearFilter() {
        this.acceptedFluid = null;
    }

    // -----------------------------------------
    // 🔵  NEOFORGE 1.21.8 SERIALIZATION SECTION
    // -----------------------------------------

    /** Called by BlockEntity.loadAdditional(...) */
    public void loadFilter(ValueInput input) {
        input.read("Filter", FluidStack.CODEC).ifPresentOrElse(
                fs -> this.acceptedFluid = fs.isEmpty() ? null : fs.copyWithAmount(1),
                () -> this.acceptedFluid = null
        );
    }

    /** Called by BlockEntity.saveAdditional(...) */
    public void saveFilter(ValueOutput output) {
        if (acceptedFluid != null && !acceptedFluid.isEmpty()) {
            output.store("Filter", FluidStack.CODEC, acceptedFluid);
        }
    }
}

package com.nick.buildcraft.content.block.refinery;

import net.minecraft.util.StringRepresentable;

public enum RefineryPart implements StringRepresentable {
    BASE("base"),
    MAGNET_SLOW("magnet_slow"),
    MAGNET_FAST("magnet_fast");

    private final String name;

    RefineryPart(String name) { this.name = name; }

    @Override
    public String getSerializedName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}

// RedstoneEngineBlock.java
package com.nick.buildcraft.content.block.engine;

import com.mojang.serialization.MapCodec;
import com.nick.buildcraft.registry.ModBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.redstone.Orientation;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

/**
 * Redstone Engine block: ring collision/outline are hollow.
 * Motion & entity push are handled in the BlockEntity.
 */
public class RedstoneEngineBlock extends BaseEngineBlock implements EntityBlock {

    /* --------- height knobs (as before) --------- */
    public static final double RING_TOP_MIN = 8.0  / 16.0; // retracted top
    public static final double RING_TOP_MAX = 16.0 / 16.0; // extended top

    /* ring thickness & core footprint (used for the hole) */
    public static final double RING_THICKNESS = 4.0 / 16.0; // 4 px tall ring
    public static final double CORE_MIN = 5.0 / 16.0;
    public static final double CORE_MAX = 11.0 / 16.0;

    /* gap around core for the hole (0 == tight to core) */
    private static final double HOLE_CLEARANCE = 0.0 / 16.0;

    /* --------------- blockstate --------------- */
    public enum Part implements net.minecraft.util.StringRepresentable {
        BASE, RING, BELLOWS;
        @Override public String getSerializedName() { return name().toLowerCase(java.util.Locale.ROOT); }
    }
    public static final EnumProperty<Part> PART  = EnumProperty.create("part", Part.class);
    public static final IntegerProperty    STAGE = IntegerProperty.create("stage", 0, 3);

    public static final MapCodec<RedstoneEngineBlock> CODEC = Block.simpleCodec(RedstoneEngineBlock::new);
    @Override protected MapCodec<RedstoneEngineBlock> codec() { return CODEC; }

    public RedstoneEngineBlock(BlockBehaviour.Properties props) {
        super(props);
        registerDefaultState(this.stateDefinition.any()
                .setValue(BlockStateProperties.POWERED, Boolean.FALSE)
                .setValue(PART, Part.BASE)
                .setValue(STAGE, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(BlockStateProperties.POWERED, PART, STAGE);
    }

    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos,
                                   Block neighborBlock, @Nullable Orientation o, boolean movedByPiston) {
        boolean powered = level.hasNeighborSignal(pos);
        if (state.getValue(BlockStateProperties.POWERED) != powered) {
            level.setBlock(pos, state.setValue(BlockStateProperties.POWERED, powered), Block.UPDATE_CLIENTS);
        }
        super.neighborChanged(state, level, pos, neighborBlock, o, movedByPiston);
    }

    @Nullable @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RedstoneEngineBlockEntity(pos, state);
    }

    @Nullable @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (type != ModBlockEntity.REDSTONE_ENGINE.get()) return null;
        return level.isClientSide
                ? (lvl, p, st, be) -> RedstoneEngineBlockEntity.clientTick(lvl, p, st, (RedstoneEngineBlockEntity) be)
                : (lvl, p, st, be) -> RedstoneEngineBlockEntity.serverTick(lvl, p, st, (RedstoneEngineBlockEntity) be);
    }

    /* --------------- static shapes --------------- */

    private static final VoxelShape BASE = box(1, 0, 1, 15, 4, 15);
    private static final VoxelShape CORE = box(5, 4, 5, 11, 12, 11);
    private static final VoxelShape BASE_PLUS_CORE = Shapes.joinUnoptimized(BASE, CORE, BooleanOp.OR);

    private static final double PX  = 1.0 / 16.0;
    private static final double EPS = 1.0 / 1024.0;

    private static final double OUT_MIN = 1 * PX, OUT_MAX = 15 * PX;

    private static double holeMin() { return CORE_MIN - HOLE_CLEARANCE; }
    private static double holeMax() { return CORE_MAX + HOLE_CLEARANCE; }

    /** Four bars (hollow frame) at offset (in blocks). */
    private static VoxelShape ringFrameAt(double off) {
        double top = RING_TOP_MIN + off;
        double bot = top - RING_THICKNESS;
        double hMin = holeMin(), hMax = holeMax();

        VoxelShape v = Shapes.empty();
        // West / East bars
        v = Shapes.joinUnoptimized(v, Shapes.create(OUT_MIN, bot, OUT_MIN, hMin,  top, OUT_MAX), BooleanOp.OR);
        v = Shapes.joinUnoptimized(v, Shapes.create(hMax,   bot, OUT_MIN, OUT_MAX, top, OUT_MAX), BooleanOp.OR);
        // North / South bars
        v = Shapes.joinUnoptimized(v, Shapes.create(hMin, bot, OUT_MIN, hMax, top, hMin), BooleanOp.OR);
        v = Shapes.joinUnoptimized(v, Shapes.create(hMin, bot, hMax,  hMax, top, OUT_MAX), BooleanOp.OR);
        return v;
    }

    /** HOLLOW “plate” while moving up: outer slab minus inner hole. */
    private static VoxelShape ringPlateAt(double off) {
        double top = RING_TOP_MIN + off;
        double bot = top - RING_THICKNESS;
        double hMin = holeMin(), hMax = holeMax();

        VoxelShape outer = Shapes.create(EPS, bot, EPS, 1.0 - EPS, top, 1.0 - EPS);
        VoxelShape inner = Shapes.create(hMin, bot, hMin, hMax,     top, hMax);
        return Shapes.joinUnoptimized(outer, inner, BooleanOp.ONLY_FIRST);
    }

    private static VoxelShape combine(VoxelShape ring) {
        return Shapes.joinUnoptimized(BASE_PLUS_CORE, ring, BooleanOp.OR);
    }

    /* --------------- collision / outline --------------- */

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        double off = 0.0;
        boolean movingUp = false;
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof RedstoneEngineBlockEntity eng) {
            off = eng.getCollisionOffset();
            movingUp = eng.isMovingUpForCollision();
        }
        VoxelShape ring = movingUp ? ringPlateAt(off) : ringFrameAt(off);
        return combine(ring);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        double off = 0.0;
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof RedstoneEngineBlockEntity eng) off = eng.getCollisionOffset();
        return combine(ringFrameAt(off));
    }

    @Override public boolean useShapeForLightOcclusion(BlockState state) { return true; }
    @Override public VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) { return Shapes.empty(); }
    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
}

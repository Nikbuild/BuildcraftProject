// src/main/java/com/nick/buildcraft/content/block/pipe/DiamondPipeBlockEntity.java
package com.nick.buildcraft.content.block.pipe;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.items.ItemStackHandler;

import java.util.EnumSet;
import java.util.Set;

/**
 * Diamond pipe with per-direction item filters.
 *
 * GUI grid is 6 rows × 9 cols. Rows map (top->bottom) to:
 *   0: BLACK  -> DOWN
 *   1: GREY   -> UP
 *   2: RED    -> NORTH
 *   3: BLUE   -> SOUTH
 *   4: GREEN  -> WEST
 *   5: YELLOW -> EAST
 *
 * (That ordering matches: "from the bottom upward: yellow(E), green(W),
 *  blue(S), red(N), grey/white(UP), black(DOWN)".)
 */
public class DiamondPipeBlockEntity extends StonePipeBlockEntity implements net.minecraft.world.MenuProvider {

    // ---- Filter storage (ghost items) ----------------------------------------------------
    // 6 rows × 9 cols = 54 slots; persisted like a normal handler.
    private final ItemStackHandler filters = new ItemStackHandler(6 * 9) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };

    public DiamondPipeBlockEntity(BlockPos pos, BlockState state) {
        super(pos, state);
    }

    // Expose to menu
    public ItemStackHandler getFilters() { return filters; }

    // ---- MenuProvider -------------------------------------------------------------------
    @Override
    public Component getDisplayName() {
        return Component.translatable("screen.buildcraft.diamond_pipe");
    }

    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new DiamondPipeMenu(id, inv, this);
    }

    // ---- Save / Load --------------------------------------------------------------------
    @Override
    protected void saveAdditional(net.minecraft.world.level.storage.ValueOutput out) {
        super.saveAdditional(out);
        net.minecraft.world.ContainerHelper.saveAllItems(out, toNonNullList(filters));
    }

    @Override
    protected void loadAdditional(net.minecraft.world.level.storage.ValueInput in) {
        super.loadAdditional(in);
        NonNullList<ItemStack> list = NonNullList.withSize(filters.getSlots(), ItemStack.EMPTY);
        net.minecraft.world.ContainerHelper.loadAllItems(in, list);
        fromNonNullList(filters, list);
    }

    private static NonNullList<ItemStack> toNonNullList(ItemStackHandler h) {
        NonNullList<ItemStack> nl = NonNullList.withSize(h.getSlots(), ItemStack.EMPTY);
        for (int i = 0; i < h.getSlots(); i++) nl.set(i, h.getStackInSlot(i));
        return nl;
    }
    private static void fromNonNullList(ItemStackHandler h, NonNullList<ItemStack> nl) {
        for (int i = 0; i < Math.min(h.getSlots(), nl.size()); i++) h.setStackInSlot(i, nl.get(i));
    }

    // =====================================================================================
    //                               FILTER  LOGIC
    // =====================================================================================

    // rows (top -> bottom) → world direction
    private static final Direction[] ROW_TO_DIR = new Direction[] {
            Direction.DOWN,   // row 0 (black)
            Direction.UP,     // row 1 (grey/white)
            Direction.NORTH,  // row 2 (red)
            Direction.SOUTH,  // row 3 (blue)
            Direction.WEST,   // row 4 (green)
            Direction.EAST    // row 5 (yellow / "vomit")
    };

    private static final int COLS = 9;
    private static final int ROWS = 6;

    /**
     * Returns the set of directions that are explicitly allowed by the filter
     * for the given stack. If no row contains a match, the set is empty
     * (meaning "no restriction" and transport can fall back to default).
     */
    public EnumSet<Direction> getAllowedDirections(ItemStack stack) {
        EnumSet<Direction> allowed = EnumSet.noneOf(Direction.class);
        if (stack.isEmpty()) return allowed;

        for (int row = 0; row < ROWS; row++) {
            if (matchesRow(row, stack)) {
                allowed.add(ROW_TO_DIR[row]);
            }
        }
        return allowed;
    }

    /**
     * Reduce a candidate set of output faces by the diamond filter.
     * If the filter yields at least one face, only those remain.
     * If the filter yields none, candidates are left unchanged.
     */
    public EnumSet<Direction> filterCandidates(ItemStack stack, Set<Direction> candidates) {
        EnumSet<Direction> filtered = getAllowedDirections(stack);
        if (filtered.isEmpty()) {
            // No filter match -> do not constrain routing
            return EnumSet.copyOf(candidates);
        }
        // keep order of 'filtered' but also require to be in 'candidates'
        filtered.retainAll(candidates);
        return filtered;
    }

    /** True if any slot in the given GUI row matches this stack. */
    public boolean matchesRow(int row, ItemStack stack) {
        int start = row * COLS;
        for (int i = 0; i < COLS; i++) {
            ItemStack f = filters.getStackInSlot(start + i);
            if (!f.isEmpty() && ItemStack.isSameItemSameComponents(f, stack)) {
                return true;
            }
        }
        return false;
    }

    // (Optional) convenience if your transport wants a single preferred face:
    public Direction pickAnyAllowed(ItemStack stack, Set<Direction> candidates) {
        EnumSet<Direction> reduced = filterCandidates(stack, candidates);
        return reduced.isEmpty() ? null : reduced.iterator().next();
    }
}

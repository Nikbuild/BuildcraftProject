package com.nick.buildcraft.content.block.refinery;

import net.neoforged.neoforge.fluids.FluidStack;
import org.jetbrains.annotations.Nullable;

/**
 * A single refinery recipe, equivalent to BuildCraft's RefineryRecipes.Recipe.
 *
 * - ingredient2 may be null (single-input recipe)
 * - All FluidStack amounts are required amounts
 * - result is the output fluid per craft
 *
 * This is a simple data container; matching is handled by RefineryRecipeCache.
 */
public final class RefineryRecipe {

    private final FluidStack ingredient1;
    @Nullable
    private final FluidStack ingredient2;   // may be null
    private final FluidStack result;

    private final int energyCost;
    private final int processingTime;

    /**
     * @param ingredient1 Required input A (never null)
     * @param ingredient2 Optional input B (nullable)
     * @param result      Output fluid stack
     * @param energyCost  Energy per crafting operation
     * @param processingTime Ticks required per craft
     */
    public RefineryRecipe(FluidStack ingredient1,
                          @Nullable FluidStack ingredient2,
                          FluidStack result,
                          int energyCost,
                          int processingTime) {

        if (ingredient1 == null || ingredient1.isEmpty())
            throw new IllegalArgumentException("ingredient1 cannot be null or empty");

        if (result == null || result.isEmpty())
            throw new IllegalArgumentException("result cannot be null or empty");

        this.ingredient1 = ingredient1.copy();
        this.ingredient2 = ingredient2 != null && !ingredient2.isEmpty() ? ingredient2.copy() : null;
        this.result = result.copy();

        this.energyCost = energyCost;
        this.processingTime = processingTime;
    }

    // -------------------------------------------------------------
    // ACCESSORS
    // -------------------------------------------------------------

    public FluidStack ingredient1() {
        return ingredient1;
    }

    @Nullable
    public FluidStack ingredient2() {
        return ingredient2;
    }

    public FluidStack result() {
        return result;
    }

    public int energyCost() {
        return energyCost;
    }

    public int processingTime() {
        return processingTime;
    }

    // -------------------------------------------------------------
    // MATCHING LOGIC – used internally by the recipe cache
    // -------------------------------------------------------------

    /**
     * Determines whether the given two fluids satisfy this recipe’s requirements.
     * Order does NOT matter (A+B == B+A).
     */
    public boolean matches(@Nullable FluidStack a, @Nullable FluidStack b) {
        // Normalize empties to nulls
        if (a != null && a.isEmpty()) a = null;
        if (b != null && b.isEmpty()) b = null;

        // Ingredient1 is always required
        if (!matchesIngredient(ingredient1, a, b))
            return false;

        // Ingredient2 may be null (single-input recipe)
        if (ingredient2 == null)
            return true;

        return matchesIngredient(ingredient2, a, b);
    }

    private static boolean matchesIngredient(FluidStack ingredient,
                                             @Nullable FluidStack a,
                                             @Nullable FluidStack b) {
        if (ingredient == null)
            return true;

        if (a != null &&
                a.getAmount() >= ingredient.getAmount() &&
                FluidStack.isSameFluidSameComponents(a, ingredient))
            return true;

        if (b != null &&
                b.getAmount() >= ingredient.getAmount() &&
                FluidStack.isSameFluidSameComponents(b, ingredient))
            return true;

        return false;
    }
}

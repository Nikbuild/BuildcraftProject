package com.nick.buildcraft.content.block.refinery;

import com.nick.buildcraft.energy.BCEnergyStorage;
import com.nick.buildcraft.registry.ModBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import org.jetbrains.annotations.Nullable;

/**
 * NeoForge 1.21.8–correct Refinery BlockEntity.
 */
public class RefineryBlockEntity extends BlockEntity implements MenuProvider {

    // Tank capacity (4 buckets each)
    public static final int TANK_CAPACITY = 4000;

    // Energy configuration
    public static final int MAX_ENERGY = 10_000;
    public static final int MAX_RECEIVE = 1_500;

    // Tanks
    public final FilterableFluidTank tank1 = new FilterableFluidTank(TANK_CAPACITY);
    public final FilterableFluidTank tank2 = new FilterableFluidTank(TANK_CAPACITY);
    public final FilterableFluidTank result = new FilterableFluidTank(TANK_CAPACITY);

    // Energy
    private final BCEnergyStorage energy =
            new BCEnergyStorage(MAX_ENERGY, MAX_RECEIVE, 0, e -> setChanged());

    // Animation state
    private float animationSpeed = 1.0f;
    private int animationStage = 0;

    // Crafting
    private int ticksSinceLastCraft = 0;
    private boolean isActive = false;

    // Sync throttling
    private int ticksSinceLastSync = 0;
    private static final int SYNC_INTERVAL = 5;

    // External fluid handler
    private final RefineryFluidHandler fluidHandler = new RefineryFluidHandler();

    public RefineryBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntity.REFINERY.get(), pos, state);
    }

    // =====================================================================
    // TICKING
    // =====================================================================

    public static void serverTick(Level level, BlockPos pos, BlockState state, RefineryBlockEntity be) {
        be.tickServer();
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, RefineryBlockEntity be) {
        be.tickClient();
    }

    private void tickServer() {
        ticksSinceLastSync++;
        if (ticksSinceLastSync >= SYNC_INTERVAL) {
            ticksSinceLastSync = 0;
            syncToClient();
        }

        isActive = false;

        RefineryRecipe recipe = findMatchingRecipe();
        if (recipe == null) {
            decreaseAnimation();
            return;
        }

        int simFill = result.fill(recipe.result().copy(), IFluidHandler.FluidAction.SIMULATE);
        if (simFill < recipe.result().getAmount()) {
            decreaseAnimation();
            return;
        }

        if (!containsInput(recipe.ingredient1()) || !containsInput(recipe.ingredient2())) {
            decreaseAnimation();
            return;
        }

        isActive = true;

        int energyCost = recipe.energyCost();
        if (energy.getEnergyStored() >= energyCost) {
            increaseAnimation();
        } else {
            decreaseAnimation();
        }

        ticksSinceLastCraft++;
        if (ticksSinceLastCraft < recipe.processingTime()) {
            return;
        }

        int canExtract = energy.extractEnergy(energyCost, true);
        if (canExtract < energyCost)
            return;

        energy.extractEnergy(energyCost, false);

        if (consumeInput(recipe.ingredient1()) && consumeInput(recipe.ingredient2())) {
            result.fill(recipe.result().copy(), IFluidHandler.FluidAction.EXECUTE);
            ticksSinceLastCraft = 0;
            setChanged();
        }
    }

    private void tickClient() {
        simpleAnimationIterate();
    }

    // =====================================================================
    // RECIPE MATCHING
    // =====================================================================

    @Nullable
    private RefineryRecipe findMatchingRecipe() {
        return RefineryRecipeCache.findRecipe(level, tank1.getFluid(), tank2.getFluid());
    }

    private boolean containsInput(@Nullable FluidStack ingredient) {
        if (ingredient == null || ingredient.isEmpty())
            return true;

        FluidStack t1 = tank1.getFluid();
        if (!t1.isEmpty() && FluidStack.isSameFluidSameComponents(t1, ingredient)
                && t1.getAmount() >= ingredient.getAmount())
            return true;

        FluidStack t2 = tank2.getFluid();
        return !t2.isEmpty() && FluidStack.isSameFluidSameComponents(t2, ingredient)
                && t2.getAmount() >= ingredient.getAmount();
    }

    private boolean consumeInput(@Nullable FluidStack ingredient) {
        if (ingredient == null || ingredient.isEmpty())
            return true;

        FluidStack t1 = tank1.getFluid();
        if (!t1.isEmpty() && FluidStack.isSameFluidSameComponents(t1, ingredient)
                && t1.getAmount() >= ingredient.getAmount()) {
            tank1.drain(ingredient.getAmount(), IFluidHandler.FluidAction.EXECUTE);
            return true;
        }

        FluidStack t2 = tank2.getFluid();
        if (!t2.isEmpty() && FluidStack.isSameFluidSameComponents(t2, ingredient)
                && t2.getAmount() >= ingredient.getAmount()) {
            tank2.drain(ingredient.getAmount(), IFluidHandler.FluidAction.EXECUTE);
            return true;
        }

        return false;
    }

    // =====================================================================
    // ANIMATION
    // =====================================================================

    private void simpleAnimationIterate() {
        if (animationSpeed > 1.0f) {
            animationStage += animationSpeed;
            if (animationStage > 300) animationStage = 100;
        } else if (animationStage > 0) {
            animationStage--;
        }
    }

    private void increaseAnimation() {
        if (animationSpeed < 2.0f) animationSpeed = 2.0f;
        else if (animationSpeed < 5.0f) animationSpeed += 0.1f;

        animationStage += animationSpeed;
        if (animationStage > 300) animationStage = 100;
    }

    private void decreaseAnimation() {
        if (animationSpeed >= 1.0f) {
            animationSpeed -= 0.1f;
            if (animationSpeed < 1.0f) animationSpeed = 1.0f;

            animationStage += animationSpeed;
            if (animationStage > 300) animationStage = 100;
        } else if (animationStage > 0) {
            animationStage--;
        }
    }

    // =====================================================================
    // FILTER MANAGEMENT
    // =====================================================================

    public void setFilter(int index, @Nullable FluidStack filter) {
        FilterableFluidTank tank = getTankByIndex(index);
        if (tank != null) {
            tank.setFilter(filter);
            setChanged();
            syncToClient();
        }
    }

    @Nullable
    public FluidStack getFilter(int index) {
        FilterableFluidTank tank = getTankByIndex(index);
        return tank != null ? tank.getFilter() : null;
    }

    public void resetFilters() {
        tank1.clearFilter();
        tank2.clearFilter();
        result.clearFilter();
        setChanged();
        syncToClient();
    }

    @Nullable
    private FilterableFluidTank getTankByIndex(int index) {
        return switch (index) {
            case 0 -> tank1;
            case 1 -> tank2;
            case 2 -> result;
            default -> null;
        };
    }

    // =====================================================================
    // FLUID HANDLER CAPABILITY
    // =====================================================================

    public IFluidHandler getFluidHandler(@Nullable Direction side) {
        return fluidHandler;
    }

    private class RefineryFluidHandler implements IFluidHandler {

        @Override
        public int getTanks() { return 3; }

        @Override
        public FluidStack getFluidInTank(int tank) {
            return switch (tank) {
                case 0 -> tank1.getFluid();
                case 1 -> tank2.getFluid();
                case 2 -> result.getFluid();
                default -> FluidStack.EMPTY;
            };
        }

        @Override
        public int getTankCapacity(int tank) { return TANK_CAPACITY; }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return switch (tank) {
                case 0 -> tank1.canAcceptFluid(stack);
                case 1 -> tank2.canAcceptFluid(stack);
                case 2 -> false;
                default -> false;
            };
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            if (resource.isEmpty()) return 0;

            int filled = tank1.fill(resource, action);
            if (filled < resource.getAmount()) {
                FluidStack rem = resource.copyWithAmount(resource.getAmount() - filled);
                filled += tank2.fill(rem, action);
            }

            if (action.execute() && filled > 0) setChanged();
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            if (resource.isEmpty() ||
                    !FluidStack.isSameFluidSameComponents(resource, result.getFluid()))
                return FluidStack.EMPTY;

            FluidStack drained = result.drain(resource.getAmount(), action);
            if (action.execute() && !drained.isEmpty()) setChanged();
            return drained;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            FluidStack drained = result.drain(maxDrain, action);
            if (action.execute() && !drained.isEmpty()) setChanged();
            return drained;
        }
    }

    // =====================================================================
    // ENERGY & MENU
    // =====================================================================

    public BCEnergyStorage getEnergyStorage() { return energy; }

    @Override
    public Component getDisplayName() {
        return Component.translatable("screen.buildcraft.refinery");
    }

    @Override
    @Nullable
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new RefineryMenu(id, inv, this);
    }

    // =====================================================================
    // VALUEOUTPUT / VALUEINPUT SERIALIZATION
    // =====================================================================

    @Override
    protected void saveAdditional(ValueOutput out) {
        super.saveAdditional(out);

        // Tanks
        out.store("Tank1", FluidStack.OPTIONAL_CODEC, tank1.getFluid());
        tank1.saveFilter(out.child("Tank1Filter"));

        out.store("Tank2", FluidStack.OPTIONAL_CODEC, tank2.getFluid());
        tank2.saveFilter(out.child("Tank2Filter"));

        out.store("Result", FluidStack.OPTIONAL_CODEC, result.getFluid());
        result.saveFilter(out.child("ResultFilter"));

        // Energy
        out.putInt("Energy", energy.getEnergyStored());

        // Animation
        out.putFloat("AnimSpeed", animationSpeed);
        out.putInt("AnimStage", animationStage);

        // Crafting timer
        out.putInt("CraftTicks", ticksSinceLastCraft);
    }

    @Override
    protected void loadAdditional(ValueInput in) {
        super.loadAdditional(in);

        // Tanks
        in.read("Tank1", FluidStack.OPTIONAL_CODEC).ifPresent(tank1::setFluid);
        tank1.loadFilter(in.child("Tank1Filter").orElse(null));

        in.read("Tank2", FluidStack.OPTIONAL_CODEC).ifPresent(tank2::setFluid);
        tank2.loadFilter(in.child("Tank2Filter").orElse(null));

        in.read("Result", FluidStack.OPTIONAL_CODEC).ifPresent(result::setFluid);
        result.loadFilter(in.child("ResultFilter").orElse(null));

        // Energy
        energy.setEnergy(in.getIntOr("Energy", 0));

        // Animation
        animationSpeed = in.getFloatOr("AnimSpeed", 1.0f);
        animationStage = in.getIntOr("AnimStage", 0);

        // Crafting
        ticksSinceLastCraft = in.getIntOr("CraftTicks", 0);
    }

    // =====================================================================
    // NETWORK SYNC
    // =====================================================================

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public net.minecraft.nbt.CompoundTag getUpdateTag(HolderLookup.Provider provider) {
        return this.saveWithoutMetadata(provider);
    }

    private void syncToClient() {
        if (level != null && !level.isClientSide) {
            setChanged();
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_CLIENTS);
        }
    }
    // =====================================================================
// PUBLIC GETTERS FOR MENU SYNC
// =====================================================================

    public float getAnimationSpeed() {
        return animationSpeed;
    }

    public int getAnimationStage() {
        return animationStage;
    }

    public int getTicksSinceLastCraft() {
        return ticksSinceLastCraft;
    }
}

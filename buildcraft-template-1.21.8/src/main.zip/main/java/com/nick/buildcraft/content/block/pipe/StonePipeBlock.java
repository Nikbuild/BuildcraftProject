package com.nick.buildcraft.content.block.pipe;

import net.minecraft.world.level.block.state.BlockBehaviour;

public class StonePipeBlock extends BaseItemPipeBlock {
    public StonePipeBlock(BlockBehaviour.Properties props) {
        super(PipeFamily.STONE, props);
    }
}

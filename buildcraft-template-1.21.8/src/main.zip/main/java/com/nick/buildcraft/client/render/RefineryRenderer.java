package com.nick.buildcraft.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.nick.buildcraft.content.block.refinery.RefineryBlockEntity;
import com.nick.buildcraft.registry.ModFluids;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.fluids.FluidStack;

/**
 * NeoForge 1.21+ compatible refinery renderer.
 * Uses only the methods available in the interfaces you provided.
 */
public final class RefineryRenderer implements BlockEntityRenderer<RefineryBlockEntity> {

    /** Original BuildCraft refinery texture. */
    private static final ResourceLocation TEX =
            ResourceLocation.fromNamespaceAndPath("buildcraft", "block/refinery/refinery");


    /** BC magnet dimensions (0.5 x 0.25 x 0.25 blocks). */
    private static final float MAG_W = 0.50f;
    private static final float MAG_H = 0.25f;
    private static final float MAG_D = 0.25f;

    public RefineryRenderer(BlockEntityRendererProvider.Context ctx) {
    }

    // --------------------------------------------------------------------- //
    // BlockEntityRenderer implementation (exact signature from the interface)
    // --------------------------------------------------------------------- //
    @Override
    public void render(
            RefineryBlockEntity be,
            float partialTick,
            PoseStack pose,
            MultiBufferSource buffers,
            int packedLight,
            int packedOverlay,
            Vec3 cameraPos
    ) {
        pose.pushPose();

        // Center on block
        pose.translate(0.5, 0.5, 0.5);

        // Match BuildCraft facing → angle
        float angle = switch (be.getBlockState().getValue(
                com.nick.buildcraft.content.block.refinery.RefineryBlock.FACING)) {
            case NORTH -> 180f;
            case SOUTH -> 0f;
            case WEST  -> 90f;
            case EAST  -> 270f;
            default -> 0f;
        };
        pose.mulPose(Axis.YP.rotationDegrees(angle));

        // Slight shrink like the old TESR
        pose.scale(0.99f, 0.99f, 0.99f);

        // Back to block-local [0..1]
        pose.translate(-0.5f, -0.5f, -0.5f);

        // Tanks use the refinery texture (entityCutout binds it)
        VertexConsumer solid = buffers.getBuffer(RenderType.entityCutout(TEX));

        renderTank(pose, solid, packedLight, packedOverlay, 0f,   0f);   // NW
        renderTank(pose, solid, packedLight, packedOverlay, 0.5f, 0f);   // NE
        renderTank(pose, solid, packedLight, packedOverlay, 0f,   0.5f); // SW
        renderTank(pose, solid, packedLight, packedOverlay, 0.5f, 0.5f); // SE

        // ---------------------------
        // Magnet animation
        // ---------------------------
        float anim = be.getAnimationStage();
        float trans1, trans2;

        if (anim <= 100f) {
            trans1 = 0.75f * (anim / 100f);
            trans2 = 0f;
        } else if (anim <= 200f) {
            trans1 = 0.75f - 0.75f * ((anim - 100f) / 100f);
            trans2 = 0.75f * ((anim - 100f) / 100f);
        } else {
            trans1 = 0.75f * ((anim - 200f) / 100f);
            trans2 = 0.75f - 0.75f * ((anim - 200f) / 100f);
        }

        float speed = be.getAnimationSpeed();
        int magnetVariant =
                (speed <= 1.0f) ? 0 :
                        (speed <= 2.5f) ? 1 :
                                (speed <= 4.5f) ? 2 : 3;

        int u = 32;
        int v = magnetVariant * 8;

        // Left magnet
        renderMagnet(
                pose, solid, packedLight, packedOverlay,
                -0.51f, trans1 - 0.5f, -0.5f,
                u, v
        );

        // Right magnet
        renderMagnet(
                pose, solid, packedLight, packedOverlay,
                -0.51f, trans2 - 0.5f, 0.25f,
                u, v
        );

        // ---------------------------
        // Fluids (simple column)
        // ---------------------------
        renderFluid(be.tank1.getFluid(), pose, buffers, packedLight, 0f, 0f);   // tank1
        renderFluid(be.tank2.getFluid(), pose, buffers, packedLight, 0f, 1f);   // tank2
        renderFluid(be.result.getFluid(), pose, buffers, packedLight, 1f, 0.5f); // result

        pose.popPose();
    }

    @Override
    public boolean shouldRenderOffScreen() {
        return true;
    }

    // =====================================================================
    // Tanks
    // =====================================================================
    private void renderTank(
            PoseStack pose,
            VertexConsumer v,
            int light,
            int overlay,
            float x,
            float z
    ) {
        pose.pushPose();
        pose.translate(x, 0f, z);
        pose.scale(0.5f, 1f, 0.5f); // 8×16×8 pixels

        // The original PNG is 64×32; tank body is at (0,0) size (32×32) in that sheet.
        renderCubeUV(pose, v, light, overlay, 0, 0, 32, 32);
        pose.popPose();
    }

    // =====================================================================
    // Magnets
    // =====================================================================
    private void renderMagnet(
            PoseStack pose,
            VertexConsumer v,
            int light,
            int overlay,
            float x, float y, float z,
            int u, int v0
    ) {
        pose.pushPose();
        pose.translate(x, y, z);
        pose.scale(MAG_W, MAG_H, MAG_D);

        // Magnet quads share the same 8×4 area in the texture, stacked vertically
        renderCubeUV(pose, v, light, overlay, u, v0, 8, 4);
        pose.popPose();
    }

    // =====================================================================
    // Fluids
    // =====================================================================
    private void renderFluid(
            FluidStack stack,
            PoseStack pose,
            MultiBufferSource buffers,
            int light,
            float x,
            float z
    ) {
        if (stack == null || stack.isEmpty()) {
            return;
        }

        float fill = Mth.clamp(stack.getAmount() / 4000f, 0f, 1f);

        pose.pushPose();
        // Same positioning as the old TESR: each tank is 0.5×1×0.5
        pose.translate(x - 0.5f, -0.5f, z - 0.5f);
        pose.scale(0.5f, 1f, 0.5f);

        // Use block atlas as translucent target (1.21+)
        VertexConsumer v = buffers.getBuffer(
                RenderType.entityTranslucent(TextureAtlas.LOCATION_BLOCKS)
        );

        renderFluidTopFace(pose, v, stack, fill, light);

        pose.popPose();
    }

    // =====================================================================
    // Geometry helpers (no vertex() calls – only official API)
    // =====================================================================
    private void renderCubeUV(
            PoseStack pose,
            VertexConsumer v,
            int light,
            int overlay,
            int u,
            int v0,
            int w,
            int h
    ) {
        float U0 = u / 64.0f;
        float U1 = (u + w) / 64.0f;
        float V0 = v0 / 32.0f;
        float V1 = (v0 + h) / 32.0f;

        PoseStack.Pose last = pose.last();

        // front (-Z)
        quad(v, last, light, overlay,
                0, 0, 0,
                1, 0, 0,
                1, 1, 0,
                0, 1, 0,
                U0, V1, U1, V0,
                0, 0, -1);

        // back (+Z)
        quad(v, last, light, overlay,
                1, 0, 1,
                0, 0, 1,
                0, 1, 1,
                1, 1, 1,
                U0, V1, U1, V0,
                0, 0, 1);

        // left (-X)
        quad(v, last, light, overlay,
                0, 0, 1,
                0, 0, 0,
                0, 1, 0,
                0, 1, 1,
                U0, V1, U1, V0,
                -1, 0, 0);

        // right (+X)
        quad(v, last, light, overlay,
                1, 0, 0,
                1, 0, 1,
                1, 1, 1,
                1, 1, 0,
                U0, V1, U1, V0,
                1, 0, 0);

        // top (+Y)
        quad(v, last, light, overlay,
                0, 1, 0,
                1, 1, 0,
                1, 1, 1,
                0, 1, 1,
                U0, V1, U1, V0,
                0, 1, 0);

        // bottom (-Y)
        quad(v, last, light, overlay,
                0, 0, 1,
                1, 0, 1,
                1, 0, 0,
                0, 0, 0,
                U0, V1, U1, V0,
                0, -1, 0);
    }

    private void quad(
            VertexConsumer v,
            PoseStack.Pose pose,
            int light,
            int overlay,
            float ax, float ay, float az,
            float bx, float by, float bz,
            float cx, float cy, float cz,
            float dx, float dy, float dz,
            float u0, float v0,
            float u1, float v1,
            float nx, float ny, float nz
    ) {
        addVertex(v, pose, ax, ay, az, u0, v1, light, overlay, nx, ny, nz);
        addVertex(v, pose, bx, by, bz, u1, v1, light, overlay, nx, ny, nz);
        addVertex(v, pose, cx, cy, cz, u1, v0, light, overlay, nx, ny, nz);
        addVertex(v, pose, dx, dy, dz, u0, v0, light, overlay, nx, ny, nz);
    }

    private void addVertex(
            VertexConsumer v,
            PoseStack.Pose pose,
            float x, float y, float z,
            float u, float vTex,
            int light,
            int overlay,
            float nx, float ny, float nz
    ) {
        v.addVertex(pose.pose(), x, y, z);
        v.setUv(u, vTex);
        v.setOverlay(overlay);
        v.setLight(light);
        v.setColor(255, 255, 255, 255);
        v.setNormal(nx, ny, nz);
    }

    private void renderFluidTopFace(
            PoseStack pose,
            VertexConsumer v,
            FluidStack fs,
            float height,
            int light
    ) {
        // ----------------------------------------------------
        // SELECT SPRITE EXACTLY LIKE THE TANK RENDERER
        // ----------------------------------------------------
        final ResourceLocation spriteLoc;

        if (fs.getFluid() == ModFluids.OIL.get() || fs.getFluid() == ModFluids.FLOWING_OIL.get()) {
            spriteLoc = ModFluids.OIL_STILL;
        } else if (fs.getFluid() == ModFluids.FUEL.get() || fs.getFluid() == ModFluids.FLOWING_FUEL.get()) {
            spriteLoc = ModFluids.FUEL_STILL;
        } else if (fs.getFluid() == Fluids.LAVA || fs.getFluid() == Fluids.FLOWING_LAVA) {
            spriteLoc = ResourceLocation.fromNamespaceAndPath("minecraft", "block/lava_still");
        } else {
            spriteLoc = ResourceLocation.fromNamespaceAndPath("minecraft", "block/water_still");
        }

        TextureAtlasSprite sprite = net.minecraft.client.Minecraft.getInstance()
                .getModelManager()
                .getAtlas(TextureAtlas.LOCATION_BLOCKS)
                .getSprite(spriteLoc);

        // ----------------------------------------------------
        // MATCH TANK TINTING LOGIC
        // ----------------------------------------------------
        int rgb;

        if (fs.getFluid() == Fluids.LAVA || fs.getFluid() == Fluids.FLOWING_LAVA) {
            rgb = 0xFF6000; // lava orange
        } else if (fs.getFluid() == ModFluids.OIL.get() || fs.getFluid() == ModFluids.FUEL.get()) {
            rgb = 0xFFFFFF; // oil & fuel use their own texture colors
        } else {
            rgb = 0xFFFFFF; // water-like → no tint here (your refinery doesn’t need biome tint)
        }

        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;

        // ----------------------------------------------------
        // DRAW TOP FACE – USING SPRITE UVs
        // ----------------------------------------------------
        PoseStack.Pose last = pose.last();

        float u0 = sprite.getU0();
        float v0 = sprite.getV0();
        float u1 = sprite.getU1();
        float v1 = sprite.getV1();

        v.addVertex(last.pose(), 0, height, 0)
                .setColor(r, g, b, 255)
                .setUv(u0, v0)
                .setLight(light)
                .setNormal(0, 1, 0);

        v.addVertex(last.pose(), 1, height, 0)
                .setColor(r, g, b, 255)
                .setUv(u1, v0)
                .setLight(light)
                .setNormal(0, 1, 0);

        v.addVertex(last.pose(), 1, height, 1)
                .setColor(r, g, b, 255)
                .setUv(u1, v1)
                .setLight(light)
                .setNormal(0, 1, 0);

        v.addVertex(last.pose(), 0, height, 1)
                .setColor(r, g, b, 255)
                .setUv(u0, v1)
                .setLight(light)
                .setNormal(0, 1, 0);
    }
}

package com.nick.buildcraft.content.block.refinery;

import net.minecraft.world.level.Level;
import net.neoforged.neoforge.fluids.FluidStack;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Global registry + lookup for refinery recipes.
 *
 * Use:
 *   RefineryRecipeCache.register(new RefineryRecipe(...))
 *   RefineryRecipeCache.findRecipe(level, fluidA, fluidB)
 */
public final class RefineryRecipeCache {

    private static final List<RefineryRecipe> RECIPES = new ArrayList<>();

    private RefineryRecipeCache() {} // static only

    // -------------------------------------------------------------
    // RECIPE REGISTRATION
    // -------------------------------------------------------------

    public static void register(RefineryRecipe recipe) {
        if (recipe == null)
            throw new IllegalArgumentException("recipe cannot be null");

        RECIPES.add(recipe);
    }

    public static List<RefineryRecipe> getAllRecipes() {
        return Collections.unmodifiableList(RECIPES);
    }

    // -------------------------------------------------------------
    // RECIPE LOOKUP
    // -------------------------------------------------------------

    @Nullable
    public static RefineryRecipe findRecipe(@Nullable Level level,
                                            @Nullable FluidStack a,
                                            @Nullable FluidStack b) {

        // Normalize empties to null
        if (a != null && a.isEmpty()) a = null;
        if (b != null && b.isEmpty()) b = null;

        for (RefineryRecipe recipe : RECIPES) {
            if (recipe.matches(a, b)) {
                return recipe;
            }
        }

        return null;
    }
}

package com.nick.buildcraft.content.block.refinery;

import com.mojang.serialization.MapCodec;
import com.nick.buildcraft.registry.ModBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

public class RefineryBlock extends BaseEntityBlock {

    // MATCHES EngineBlock: horizontal facing only
    public static final EnumProperty<Direction> FACING =
            EnumProperty.create("facing", Direction.class, Direction.Plane.HORIZONTAL);

    public RefineryBlock(Properties props) {
        super(props);

        // Register default blockstate (NECESSARY for renderer!)
        this.registerDefaultState(
                this.stateDefinition.any()
                        .setValue(FACING, Direction.NORTH)
        );
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public InteractionResult useWithoutItem(
            BlockState state,
            Level level,
            BlockPos pos,
            Player player,
            BlockHitResult hit
    ) {
        if (!level.isClientSide) {
            BlockEntity be = level.getBlockEntity(pos);

            if (be instanceof MenuProvider provider) {
                player.openMenu(provider);
            } else {
                player.displayClientMessage(
                        Component.literal("Refinery missing its BlockEntity!"), true
                );
            }
        }

        return level.isClientSide ? InteractionResult.SUCCESS : InteractionResult.CONSUME;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RefineryBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(
            Level level,
            BlockState state,
            BlockEntityType<T> type
    ) {
        if (type != ModBlockEntity.REFINERY.get())
            return null;

        return (lvl, p, st, be) -> {
            RefineryBlockEntity refinery = (RefineryBlockEntity) be;

            if (lvl.isClientSide)
                RefineryBlockEntity.clientTick(lvl, p, st, refinery);
            else
                RefineryBlockEntity.serverTick(lvl, p, st, refinery);
        };
    }

    @Override
    protected void createBlockStateDefinition(
            StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder
    ) {
        builder.add(FACING);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(RefineryBlock::new);
    }
}

package com.nick.buildcraft.content.block.pipe;

import net.minecraft.world.level.block.state.BlockBehaviour;

public class GoldPipeBlock extends BaseItemPipeBlock {
    public GoldPipeBlock(BlockBehaviour.Properties props) {
        super(PipeFamily.GOLD, props);
    }
}

// RedstoneEngineBlockEntity.java
package com.nick.buildcraft.content.block.engine;

import com.nick.buildcraft.energy.Energy;
import com.nick.buildcraft.registry.ModBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;

/**
 * Bang-return profile:
 * - Up-stroke: one clean "bang" to full extension in a single tick.
 * - Down-stroke: smooth, slower return over multiple ticks.
 */
public class RedstoneEngineBlockEntity extends BaseEngineBlockEntity {

    private static final float  PROGRESS_STEP_DOWN = 0.03f; // return speed (bigger = faster down)
    private static final double PUSH_EPSILON       = 1.0e-5;

    private static final float MAX_OFFSET_BLOCKS =
            (float)(RedstoneEngineBlock.RING_TOP_MAX - RedstoneEngineBlock.RING_TOP_MIN);

    private float  progress  = 0.0f; // [0..1]
    private float  progressO = 0.0f; // [0..1]
    private boolean goingUp  = true; // next stroke is the "bang" upward

    public RedstoneEngineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntity.REDSTONE_ENGINE.get(), pos, state);
    }

    @Override
    protected boolean isActive(BlockState state) {
        return state.hasProperty(BlockStateProperties.POWERED) && state.getValue(BlockStateProperties.POWERED);
    }

    @Override
    protected int getGenerationPerTick() {
        int w = warmupTicks();
        if (w >= Energy.REDSTONE_ENGINE_WARMUP_TICKS) return Energy.REDSTONE_ENGINE_GEN_HOT;
        if (w >= Energy.REDSTONE_ENGINE_WARMUP_TICKS / 2) return Energy.REDSTONE_ENGINE_GEN_WARM;
        return Energy.REDSTONE_ENGINE_GEN_COLD;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, RedstoneEngineBlockEntity be) {
        BaseEngineBlockEntity.serverTick(level, pos, state, be);
        be.tick(level, pos, state);
    }
    public static void clientTick(Level level, BlockPos pos, BlockState state, RedstoneEngineBlockEntity be) {
        be.tick(level, pos, state);
    }

    private void tick(Level level, BlockPos pos, BlockState state) {
        boolean powered = isActive(state);
        progressO = progress;

        if (powered) {
            if (goingUp) {
                // One-tick "bang" upward to fully extended
                float next = 1.0f;
                if (!level.isClientSide && next != progress) pushEntitiesLikePiston(level, pos, progress, next);
                progress = next;
                goingUp = false; // start slow return
            } else {
                // Smooth, slower return
                float next = Math.max(0.0f, progress - PROGRESS_STEP_DOWN);
                if (!level.isClientSide && next != progress) pushEntitiesLikePiston(level, pos, progress, next);
                progress = next;
                if (progress == 0.0f) goingUp = true; // ready for next bang
            }
        } else {
            // Unpowered: retract smoothly; next time, start with an up "bang"
            float next = Math.max(0.0f, progress - PROGRESS_STEP_DOWN);
            if (!level.isClientSide && next != progress) pushEntitiesLikePiston(level, pos, progress, next);
            progress = next;
            if (progress == 0.0f) goingUp = true;
        }
    }

    private void pushEntitiesLikePiston(Level level, BlockPos pos, float oldProg, float newProg) {
        double offPrev = MAX_OFFSET_BLOCKS * oldProg;
        double offNow  = MAX_OFFSET_BLOCKS * newProg;
        double dy      = offNow - offPrev;
        if (dy == 0.0) return;

        boolean movingUp = dy > 0;
        double moveAmt   = Math.abs(dy);

        VoxelShape start = ringPlateAt(pos, offPrev);
        VoxelShape end   = ringPlateAt(pos, offNow);

        AABB a0 = start.bounds(), a1 = end.bounds();
        AABB sweep = new AABB(
                Math.min(a0.minX, a1.minX), Math.min(a0.minY, a1.minY), Math.min(a0.minZ, a1.minZ),
                Math.max(a0.maxX, a1.maxX), Math.max(a0.maxY, a1.maxY), Math.max(a0.maxZ, a1.maxZ)
        );

        List<Entity> candidates = level.getEntities(null, sweep);
        if (candidates.isEmpty()) return;

        List<AABB> partsStart = start.toAabbs();
        List<AABB> partsEnd   = end.toAabbs();
        List<AABB> sweptParts = new ArrayList<>(partsStart.size());
        for (int i = 0; i < partsStart.size(); i++) {
            AABB s = partsStart.get(i), e = partsEnd.get(i);
            sweptParts.add(new AABB(
                    s.minX, Math.min(s.minY, e.minY), s.minZ,
                    s.maxX, Math.max(s.maxY, e.maxY), s.maxZ
            ));
        }

        for (Entity ent : candidates) {
            if (ent.isSpectator() || ent.getPistonPushReaction() == PushReaction.IGNORE) continue;

            double needed = 0.0;
            for (AABB sp : sweptParts) {
                if (!sp.intersects(ent.getBoundingBox())) continue;
                double pen = movingUp
                        ? sp.maxY - ent.getBoundingBox().minY
                        : ent.getBoundingBox().maxY - sp.minY;
                if (pen > needed) needed = pen;
                if (needed >= moveAmt) break;
            }
            if (needed <= 0.0) continue;

            double push = Math.min(needed + PUSH_EPSILON, moveAmt);
            if (!movingUp) push = -push;

            Vec3 before = ent.position();
            ent.move(MoverType.PISTON, new Vec3(0.0, push, 0.0));
            ent.applyEffectsFromBlocks(before, ent.position());
            ent.fallDistance = 0.0f;
        }
    }

    /** HOLLOW plate used for pushing (outer slab minus inner hole). */
    private static VoxelShape ringPlateAt(BlockPos pos, double off) {
        double top = RedstoneEngineBlock.RING_TOP_MIN + off;
        double bot = top - RedstoneEngineBlock.RING_THICKNESS;

        double x0 = pos.getX(), y0 = pos.getY(), z0 = pos.getZ();

        double hMin = RedstoneEngineBlock.CORE_MIN - 0.0/16.0;
        double hMax = RedstoneEngineBlock.CORE_MAX + 0.0/16.0;

        VoxelShape outer = Shapes.create(x0,       y0 + bot, z0,
                x0 + 1.0, y0 + top, z0 + 1.0);
        VoxelShape inner = Shapes.create(x0 + hMin, y0 + bot, z0 + hMin,
                x0 + hMax, y0 + top, z0 + hMax);
        return Shapes.joinUnoptimized(outer, inner, BooleanOp.ONLY_FIRST);
    }

    /* ----- helpers for the block ----- */
    public float getRenderOffset(float partialTicks) {
        return Mth.lerp(partialTicks, progressO, progress) * MAX_OFFSET_BLOCKS;
    }
    public double getCollisionOffset() {
        return progress * MAX_OFFSET_BLOCKS;
    }
    public boolean isMovingUpForCollision() {
        return progress > progressO && progress < 1.0f;
    }
}

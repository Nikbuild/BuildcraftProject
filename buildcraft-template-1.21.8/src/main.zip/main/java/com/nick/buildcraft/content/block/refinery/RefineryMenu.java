package com.nick.buildcraft.content.block.refinery;

import com.nick.buildcraft.registry.ModMenus;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

/**
 * Menu (server <-> client container) for the BuildCraft-style refinery.
 * Handles syncing fluids, energy, animation, and timers to the client.
 */
public class RefineryMenu extends AbstractContainerMenu {

    private final RefineryBlockEntity refinery;
    private final ContainerLevelAccess access;

    // We will sync: energy, animSpeed, animStage, craftTicks
    private final SimpleContainerData data = new SimpleContainerData(4);

    public RefineryMenu(int id, Inventory playerInv, RefineryBlockEntity refinery) {
        super(ModMenus.REFINERY.get(), id);
        this.refinery = refinery;
        this.access = ContainerLevelAccess.create(refinery.getLevel(), refinery.getBlockPos());

        // Sync values
        addDataSlots(data);
    }

    /**
     * Client constructor — BlockEntity is restored via world lookup.
     */
    public RefineryMenu(int id, Inventory playerInv) {
        super(ModMenus.REFINERY.get(), id);

        // This runs only on client before BE is synced — we MUST NOT use null refinery.
        this.refinery = null;
        this.access = ContainerLevelAccess.NULL;

        addDataSlots(data);
    }

    // ------------------------------------------------------------------
    // DATA SYNCING
    // ------------------------------------------------------------------

    @Override
    public void broadcastChanges() {
        super.broadcastChanges();

        if (refinery != null) {
            data.set(0, refinery.getEnergyStorage().getEnergyStored());
            data.set(1, (int) (refinery.getAnimationSpeed() * 100));  // scaled
            data.set(2, refinery.getAnimationStage());
            data.set(3, refinery.getTicksSinceLastCraft());
        }
    }

    // Energy
    public int getEnergy() { return data.get(0); }

    // Animation speed (scaled *100)
    public float getAnimationSpeed() { return data.get(1) / 100f; }

    public int getAnimationStage() { return data.get(2); }

    public int getCraftTicks() { return data.get(3); }

    public RefineryBlockEntity getRefinery() { return refinery; }

    // ------------------------------------------------------------------
    // REQUIRED METHODS
    // ------------------------------------------------------------------

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, refinery != null ? refinery.getBlockState().getBlock() : null);
    }

    @Override
    public @NotNull ItemStack quickMoveStack(@NotNull Player player, int index) {
        // No items used in this machine; nothing to shift-click.
        return ItemStack.EMPTY;
    }
}
